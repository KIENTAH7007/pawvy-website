# Patch 120 — Stripe Checkout (card + PayNow), BUTTONS wired in, real free-shipping enforcement

This is the big one: pawvy.co can now actually take payment. Cart → Checkout →
Stripe → real order, real inventory deduction, real BUTTONS earn/redeem.

## What's new

- **Real checkout.** The Cart's "Checkout — coming soon" placeholder is now a
  working button. Card and PayNow both work automatically — Stripe shows
  whichever the customer wants to use on its own hosted payment page.
- **Guest checkout works too**, not just logged-in customers — just needs an
  email + a PDPA consent tick, same pattern as POS checkout already uses.
- **BUTTONS are fully wired in**, only for logged-in customers: they can
  redeem existing B (capped at 30% of subtotal, same rule as the spec), and
  they earn new B on the purchase — including the first-purchase 100B bonus
  and referral bonuses, exactly like the spec already defined.
- **The $60 free-shipping threshold is now enforced by the server**, not just
  shown as a UI hint in the cart. The number can't be tampered with client-side.
- **A real `orders` table** — well, `website_orders` (see "Why not just
  `orders`" below) — plus a `website_order_items` table.
- **Nothing is committed until Stripe actually confirms payment.** Inventory
  deduction, the `sales` ledger row, and BUTTONS earn/redeem all happen in the
  webhook handler, never at the moment someone clicks "Checkout" — same
  pattern the Order Portal and POS already use (nothing reserves stock ahead
  of a committed sale).

## Files changed

**pawvy-app (backend):**
- `server/database.js` — added `website_orders` + `website_order_items` tables
- `server/lib/buttons.js` — added `previewRedemption()` (a non-committing preview of the redemption cap, used to size the Stripe discount before payment is real)
- `server/utils/notify.js` — added `notifyNewWebsiteOrder()` (Telegram + email, same pattern as the existing Order Portal notification)
- `server/routes/checkout.js` — **new file.** `POST /create-session`, `POST /webhook`, `GET /session/:sessionId`
- `server/index.js` — mounted `/api/checkout`, added it to the PIN-gate exclusion list, and — important — branched body parsing so the Stripe webhook route gets the **raw** request body it needs for signature verification (Stripe's SDK can't verify a signature against an already-JSON-parsed body)
- `package.json` — added the `stripe` npm package

**pawvy-website (frontend):**
- `lib/api.js` — added `checkoutApi` (create session, get session)
- `app/cart/page.js` — real checkout button, contact/shipping form (or account details if logged in), BUTTONS redemption input
- `app/checkout/success/page.js` — **new file.** Order confirmation page Stripe redirects back to

## Why a new `website_orders` table, not `orders`

`/api/orders` and the `portal_orders` table already exist — but that's the
**B2B wholesale approval queue** (partners submit an order, staff reviews and
approves it, no payment gateway involved). Completely different flow. Reusing
that name for real paid B2C checkout orders would've been confusing, so this
is a new, separate table.

## What was tested, and how

I don't have a way to actually reach `api.stripe.com` from where I build and
test these patches — only your Railway deployment can do that. So testing
split into two parts:

**Fully tested locally (39 automated checks, all passing):**
- Guest checkout: session creation, subtotal/shipping/total math
- Server-side $60 free-shipping enforcement (can't be bypassed client-side)
- Stock validation (rejects over-quantity requests with the real number left)
- PDPA consent required for guest checkout; email required
- Webhook signature verification — using the **real** Stripe SDK's signing/
  verification code (this part needs no network call at all, so it's tested
  against the real thing, not a guess)
- Invalid webhook signatures are rejected
- Webhook fulfillment: real `sales` row created, inventory deducted, order
  flips to `paid`
- **Duplicate webhook events don't double-charge inventory** (Stripe does
  send duplicates sometimes — this is idempotent)
- Failed/declined async payment (the PayNow decline path) marks the order
  `payment_failed` and — critically — does NOT deduct inventory
- Logged-in checkout: BUTTONS redemption correctly capped by whichever is
  lower, the 30% rule or the customer's actual balance
- BUTTONS balance is untouched at checkout time, only actually drawn down
  once the webhook confirms payment
- First-purchase 100B bonus awarded once, not again on a second order
- Order confirmation lookup endpoint returns the right data

**Can only be tested live, once deployed (I'd like you to try this first):**
- The actual `stripe.checkout.sessions.create()` call — i.e. does clicking
  "Checkout" on the real site actually take you to a real Stripe payment page
- PayNow actually rendering as an option there
- The real webhook arriving from Stripe's servers (not simulated)

I'm confident in this because every piece of *my own* logic around that one
API call is tested — but the call itself needs your live keys and a
reachable webhook URL, neither of which exist until this is on Railway.

## What you need to do before/after deploying this patch

### 1. Add two more Railway environment variables (backend service)

You already added `STRIPE_SECRET_KEY` and `STRIPE_PUBLISHABLE_KEY`. Add:

| Variable | Value |
|---|---|
| `WEBSITE_URL` | Your **website's** Railway URL, e.g. `https://pawvy-website-production.up.railway.app` (this becomes `https://pawvy.co` later, at the DNS cutover step) |
| `STRIPE_WEBHOOK_SECRET` | See step 2 below — you can't get this until the backend is deployed |

### 2. Register the webhook in Stripe, get the signing secret

Once `pawvy-app` is deployed with this patch:

1. Stripe Dashboard (**Test mode** still) → **Developers** → **Webhooks**
2. Click **Add endpoint**
3. Endpoint URL: `https://<your-pawvy-app-backend-url>/api/checkout/webhook`
4. Select events to listen to:
   - `checkout.session.completed`
   - `checkout.session.async_payment_succeeded`
   - `checkout.session.async_payment_failed`
5. Click **Add endpoint**, then click into it and reveal the **Signing secret** (`whsec_...`)
6. Add that as `STRIPE_WEBHOOK_SECRET` in Railway (step 1 above)

### 3. Test a real checkout end-to-end

With test-mode keys still in place (no real money moves):
1. Add something to cart on the real site, go to checkout
2. On Stripe's payment page, use a [Stripe test card](https://docs.stripe.com/testing#cards) — `4242 4242 4242 4242`, any future expiry, any CVC
3. Confirm you land on the success page, and that in the internal Pawvy App the order shows up in the Sales Ledger with channel "Website Order"
4. Try PayNow the same way — Stripe's test mode simulates a PayNow QR flow you can auto-confirm

If anything doesn't work as expected, send me what you see (screenshot +
Railway logs if there's an error) and I'll debug from there — this is the one
part I genuinely can't fully verify without your help, since I can't reach
Stripe's servers from where I do this work.

## Known limitations / things left as-is on purpose

- **Shipping is still a flat $3** (or free over $60) — no real courier-rate
  lookup. Matches what the cart already showed as a UI hint before this patch;
  now it's just server-enforced too.
- **Actual courier cost isn't captured** — the `sales.shipping_cost` field is
  left at 0 for website orders (you'll have this for POS/wholesale but not
  here yet, since there's no courier integration). Worth revisiting once you
  pick a shipping partner.
- **Stock isn't "reserved"** while someone is on Stripe's payment page. If two
  people check out the last unit at the same time, whoever's webhook lands
  second can push inventory negative. This matches how every other checkout
  flow in this app already works (Order Portal, POS) — nobody reserves stock
  ahead of a committed sale — but flagging it since payment flows sometimes
  expect this. I log a warning when it happens so it's visible, not silent.
- **First-purchase bonus is scoped to "first paid website order"** specifically
  — it doesn't check POS/wholesale sales history. If a customer's first-ever
  purchase was in person at an event, they'll still get the 100B bonus on
  their first *website* order too. This seemed like the more generous, less
  confusing interpretation, but flagging it in case you'd rather it check
  across every channel.
