# Patch 122 (website half) — Change Password on the Account page

## What's new

The Account page now has a password section at the bottom:
- If the customer already has a password: **"Change Password"**
- If they've only ever used the email link: **"Set a Password"**

This closes a real gap: the "forgot password" magic-link flow
(`login-verify`) sends an existing customer straight to `/account`, but
until now that page had no password field at all — there was genuinely no
way to set a new one after using the reset link. `/set-password` only ever
triggers for a brand-new customer's first-time setup.

No backend changes needed — this reuses the `POST /api/customers/me/set-password`
endpoint and `customerApi.setPassword()` call that already existed for the
first-time-setup flow.

## Files changed

- `app/account/page.js` — added the password form section

## Tested

`npm run build` clean, no compile errors. Same validation as the existing
`/set-password` page (8-char minimum, confirm-match check) since it calls
the identical backend endpoint.

## Deploy together with the pawvy-app half of Patch 122

This is the companion to `patch122-pawvy-app.zip` (Stripe fee visibility in
the Sales Ledger + BUTTONS ledger in Customer Details). Extract this into
`pawvy-website`, push both repos together, and it's all one deploy.
